import os
import time
import random
import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from src.preprocessing import TextPreprocessor
from src.model import ToxicityClassifier, DeepLearningToxicityClassifier
from src.moderator import ContentModerator
from train import run_training_pipeline

# ---------------------------------------------------------
# Page Configurations & Styling
# ---------------------------------------------------------
st.set_page_config(
    page_title="NEUTRA-MOD // Toxic Comment Filtering",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Dark-themed glassmorphism custom CSS injection
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&family=Rajdhani:wght@600;700&display=swap');
    
    /* Overall adjustments */
    html, body, [class*="css"] {
        font-family: 'Outfit', sans-serif;
    }
    
    h1, h2, h3, .title-text {
        font-family: 'Rajdhani', sans-serif;
        font-weight: 700;
        letter-spacing: 1px;
    }
    
    /* Sidebar glow */
    [data-testid="stSidebar"] {
        background-color: #0E1117;
        border-right: 1px solid #1F2937;
    }
    
    /* Neon gradients & cards */
    .premium-header {
        background: linear-gradient(135deg, #FF1744 0%, #D81B60 30%, #2979FF 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-family: 'Rajdhani', sans-serif;
        font-size: 3rem;
        margin-bottom: 0.1rem;
        font-weight: 800;
    }
    
    .glow-card-green {
        background-color: #1A1C23;
        border-left: 5px solid #00E676;
        border-radius: 6px;
        padding: 15px;
        margin-bottom: 12px;
        box-shadow: 0 4px 6px -1px rgba(0, 230, 118, 0.1);
    }
    
    .glow-card-yellow {
        background-color: #1A1C23;
        border-left: 5px solid #FFC107;
        border-radius: 6px;
        padding: 15px;
        margin-bottom: 12px;
        box-shadow: 0 4px 6px -1px rgba(255, 193, 7, 0.1);
    }
    
    .glow-card-orange {
        background-color: #1A1C23;
        border-left: 5px solid #FF9100;
        border-radius: 6px;
        padding: 15px;
        margin-bottom: 12px;
        box-shadow: 0 4px 6px -1px rgba(255, 145, 0, 0.1);
    }
    
    .glow-card-red {
        background-color: #1A1C23;
        border-left: 5px solid #FF1744;
        border-radius: 6px;
        padding: 15px;
        margin-bottom: 12px;
        box-shadow: 0 4px 6px -1px rgba(255, 23, 68, 0.1);
    }
    
    /* Chat layout styling */
    .chat-container {
        max-height: 480px;
        overflow-y: auto;
        padding: 10px;
        background-color: #0E1117;
        border: 1px solid #1F2937;
        border-radius: 8px;
        margin-bottom: 15px;
    }
    
    .chat-bubble-user {
        background: #252836;
        color: #FFFFFF;
        padding: 10px 14px;
        border-radius: 12px 12px 12px 0;
        margin-bottom: 10px;
        max-width: 80%;
    }
    
    .chat-bubble-system {
        background: rgba(216, 27, 96, 0.15);
        color: #FF80AB;
        border: 1px solid rgba(216, 27, 96, 0.3);
        padding: 8px 12px;
        border-radius: 6px;
        margin: 10px 0;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .badge-warn {
        background-color: #FF9100;
        color: black;
        padding: 2px 6px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 0.75rem;
    }
    
    .badge-mute {
        background-color: #D81B60;
        color: white;
        padding: 2px 6px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 0.75rem;
    }
    
    .badge-ban {
        background-color: #FF1744;
        color: white;
        padding: 2px 6px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 0.75rem;
    }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------
# Load Moderation System State
# ---------------------------------------------------------
MODEL_PATH = "models/toxicity_classifier.joblib"

@st.cache_resource
def load_classical_model():
    if os.path.exists(MODEL_PATH):
        return ToxicityClassifier.load(MODEL_PATH)
    return None

@st.cache_resource
def load_deep_learning_model():
    # Will lazily load unitary/toxic-bert from HuggingFace
    clf = DeepLearningToxicityClassifier(model_name='unitary/toxic-bert')
    return clf

# Initialize session states
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = [
        {"username": "Cyber_Striker", "text": "let's push outer tower", "action": "ALLOW", "severity": 0.2, "timestamp": time.time() - 30},
        {"username": "ProGamer_99", "text": "ggwp guys close one!", "action": "ALLOW", "severity": 0.1, "timestamp": time.time() - 25},
        {"username": "RageMonster", "text": "stfu u absolute garbage", "action": "WARN", "severity": 1.8, "timestamp": time.time() - 20},
        {"username": "Moderator_Bot", "text": "[SYSTEM ALERT] RageMonster has been WARNED. Reason: Please keep chat respectful.", "action": "SYSTEM", "severity": 0.0, "timestamp": time.time() - 19},
        {"username": "Cyber_Striker", "text": "wow, nice counter rage lol", "action": "ALLOW", "severity": 0.4, "timestamp": time.time() - 10}
    ]

if 'user_action_history' not in st.session_state:
    st.session_state.user_action_history = []

if 'active_players' not in st.session_state:
    st.session_state.active_players = {
        "Cyber_Striker": "Active",
        "ProGamer_99": "Active",
        "RageMonster": "Warned",
        "ShadowNinja": "Active",
        "Toxic_Avenger": "Active"
    }

# Dynamic player message presets for simulation
SIMULATED_MESSAGES = [
    ("ShadowNinja", "i need some backup on the left portal", "ALLOW"),
    ("ProGamer_99", "buy aimbot at hacklords.com for 5 dollars!", "WARN"),
    ("Toxic_Avenger", "kys garbage bot uninstall life", "BAN"),
    ("RageMonster", "fuck this lag and fuck this stupid teammate", "MUTE"),
    ("ShadowNinja", "we can still secure the victory, hold defense!", "ALLOW"),
    ("Cyber_Striker", "nice heal thx so much", "ALLOW")
]

# ---------------------------------------------------------
# Sidebar Panel - Configuration & Model Control
# ---------------------------------------------------------
st.sidebar.markdown("<h2 style='color:#FF1744;'>🛡️ CONTROL CENTER</h2>", unsafe_allow_html=True)
st.sidebar.write("Configure the active AI model parameters and rule thresholds.")

# 1. Model Backend Selector
model_type = st.sidebar.radio(
    "AI Model Backend",
    ["⚡ Classical ML (Fast TF-IDF)", "🧠 Deep Learning (DistilBERT)"],
    help="Classical ML runs immediately offline in under 5ms. Deep Learning loads a state-of-the-art transformer model (unitary/toxic-bert) for ultimate accuracy."
)

# Load Classifier
model = None
is_model_trained = os.path.exists(MODEL_PATH)

if model_type.startswith("⚡"):
    model = load_classical_model()
else:
    with st.sidebar.status("Loading Deep Learning Model (unitary/toxic-bert)...", expanded=False) as dl_status:
        try:
            model = load_deep_learning_model()
            dl_status.update(label="Deep Learning Model Loaded!", state="complete")
        except Exception as e:
            st.sidebar.error(f"Failed to load Deep Learning model: {e}")

# 2. Rule Customizers
st.sidebar.markdown("<hr style='border-color: #1F2937;'/>", unsafe_allow_html=True)
st.sidebar.markdown("### ⚙️ Threshold Tuning (0.0 to 5.0)")
warn_thresh = st.sidebar.slider("⚠️ Warn Threshold", 0.5, 2.0, 1.0, 0.1)
mute_thresh = st.sidebar.slider("🔇 Mute Threshold", 2.0, 3.8, 2.5, 0.1)
ban_thresh = st.sidebar.slider("🚫 Ban Threshold", 3.5, 5.0, 4.0, 0.1)

# 3. Model Training Action (Integrated Trigger)
st.sidebar.markdown("<hr style='border-color: #1F2937;'/>", unsafe_allow_html=True)
st.sidebar.markdown("### ⚡ Model Training")
if not is_model_trained:
    st.sidebar.warning("Trained model file `models/toxicity_classifier.joblib` not found. Live predictions will be disabled until trained.")
    if st.sidebar.button("⚙️ Train Classical Model Now"):
        with st.spinner("Training ML pipeline and optimizing thresholds (takes ~5s)..."):
            try:
                run_training_pipeline()
                st.cache_resource.clear() # clear cache to reload model
                st.success("Model trained successfully! Loading pipeline...")
                st.rerun()
            except Exception as e:
                st.error(f"Error during training: {e}")
else:
    st.sidebar.success("Classical Model File: Detected & Loaded")
    if st.sidebar.button("🔄 Retrain ML Classifier"):
        with st.spinner("Retraining model pipeline..."):
            try:
                run_training_pipeline()
                st.cache_resource.clear()
                st.success("Model successfully retrained!")
                st.rerun()
            except Exception as e:
                st.error(f"Error: {e}")

# ---------------------------------------------------------
# Main Page View
# ---------------------------------------------------------
st.markdown("<div class='premium-header'>NEUTRA-MOD</div>", unsafe_allow_html=True)
st.markdown("<h3 style='margin-top: -15px; color:#9E9E9E; font-weight: 300;'>High-Fidelity Live-Chat Toxic Comment Filtering System</h3>", unsafe_allow_html=True)

# Tabs
tab_simulator, tab_analytics, tab_policy = st.tabs([
    "🕹️ Live Chat Simulator", 
    "📊 Admin Analytics Dashboard", 
    "📜 Mitigation Strategies"
])

# Initialize Content Moderator wrapper
moderator = ContentModerator(classifier=model)
moderator.threshold_warn = warn_thresh
moderator.threshold_mute = mute_thresh
moderator.threshold_ban = ban_thresh

# ---------------------------------------------------------
# TAB 1: Live Chat Simulator
# ---------------------------------------------------------
with tab_simulator:
    col_chat, col_player_status = st.columns([3, 1])
    
    with col_chat:
        st.markdown("### 💬 Live Game Server Chat Lobby")
        
        # Simulation controls
        sim_cols = st.columns([4, 1])
        with sim_cols[1]:
            if st.button("🤖 Sim Player Message"):
                # Pick a random preset
                user, msg_text, _ = random.choice(SIMULATED_MESSAGES)
                
                # Fetch user history for rate-limit / spam checking
                user_hist = [m for m in st.session_state.chat_history if m.get('username') == user]
                
                # Run moderation
                report = moderator.analyze_message(msg_text, username=user, user_history=user_hist)
                
                # Update player status
                if report['action'] == "WARN":
                    st.session_state.active_players[user] = "Warned"
                elif report['action'] == "MUTE":
                    st.session_state.active_players[user] = "Muted"
                elif report['action'] == "BAN":
                    st.session_state.active_players[user] = "Banned"
                
                # Add to history
                st.session_state.chat_history.append({
                    "username": user,
                    "text": report['redacted_text'],
                    "original": report['original_text'],
                    "action": report['action'],
                    "severity": report['severity_score'],
                    "timestamp": time.time()
                })
                
                # If toxic, insert a System Bot intervention message
                if report['action'] in ["WARN", "MUTE", "BAN"]:
                    st.session_state.chat_history.append({
                        "username": "Moderator_Bot",
                        "text": f"[SYSTEM ALERT] {user} has been {report['action']}ED. Reason: {report['action_reason']}",
                        "action": "SYSTEM",
                        "severity": 0.0,
                        "timestamp": time.time()
                    })
                    
                st.rerun()
                
        with sim_cols[0]:
            st.caption("Click the simulation button to generate typical player comments and observe automatic moderation bot interventions.")
            
        # Draw the scrollable chat
        chat_html = "<div class='chat-container'>"
        for msg in st.session_state.chat_history[-15:]:  # Display last 15 messages
            username = msg["username"]
            text = msg["text"]
            action = msg["action"]
            
            if username == "Moderator_Bot":
                chat_html += f"<div class='chat-bubble-system'>🛡️ <b>{text}</b></div>"
            else:
                badge = ""
                if action == "WARN":
                    badge = "<span class='badge-warn'>WARN</span>"
                elif action == "MUTE":
                    badge = "<span class='badge-mute'>MUTE</span>"
                elif action == "BAN":
                    badge = "<span class='badge-ban'>BAN</span>"
                    
                # Format timestamp
                time_str = time.strftime('%H:%M:%S', time.localtime(msg["timestamp"]))
                chat_html += f"""
                <div style='margin-bottom: 12px; border-bottom: 1px solid #1F2937; padding-bottom: 6px;'>
                    <span style='color: #888; font-size: 0.8rem;'>[{time_str}]</span> 
                    <strong style='color: #2979FF;'>{username}</strong> {badge}: 
                    <span style='color: #E2E8F0; margin-left: 5px;'>{text}</span>
                </div>
                """
        chat_html += "</div>"
        st.markdown(chat_html, unsafe_allow_html=True)
        
        # User input interactive chat box
        user_input = st.chat_input("Join the lobby chat... (Type something to test the AI moderation response)")
        if user_input:
            # Check player status of the tester
            tester_name = "You_The_Player"
            
            # Moderation report
            user_hist = [m for m in st.session_state.chat_history if m.get('username') == tester_name]
            report = moderator.analyze_message(user_input, username=tester_name, user_history=user_hist)
            
            # Show live analyzer card at top of submission
            st.session_state.chat_history.append({
                "username": tester_name,
                "text": report['redacted_text'],
                "original": report['original_text'],
                "action": report['action'],
                "severity": report['severity_score'],
                "timestamp": time.time()
            })
            
            # Add action if warned/muted/banned
            if report['action'] in ["WARN", "MUTE", "BAN"]:
                st.session_state.chat_history.append({
                    "username": "Moderator_Bot",
                    "text": f"[SYSTEM ALERT] {tester_name} has been {report['action']}ED. Reason: {report['action_reason']}",
                    "action": "SYSTEM",
                    "severity": 0.0,
                    "timestamp": time.time()
                })
                
            # Log player actions for analytics tab
            st.session_state.user_action_history.append(report)
            st.rerun()
            
    with col_player_status:
        st.markdown("### 👥 Players in Server")
        
        for p, status in st.session_state.active_players.items():
            color = "#00E676"  # Active (Green)
            if status == "Warned":
                color = "#FFC107"  # Yellow
            elif status == "Muted":
                color = "#FF9100"  # Orange
            elif status == "Banned":
                color = "#FF1744"  # Red
                
            st.markdown(f"""
            <div style='background-color: #1A1C23; padding: 10px; border-radius: 6px; margin-bottom: 8px; border-left: 3px solid {color}; display: flex; justify-content: space-between; align-items: center;'>
                <span style='font-weight: 600; color: white;'>{p}</span>
                <span style='color: {color}; font-size: 0.85rem; font-weight: bold;'>● {status.upper()}</span>
            </div>
            """, unsafe_allow_html=True)
            
    # Dynamic live detailed output display of the LAST message analyzed
    last_user_msgs = [m for m in st.session_state.chat_history if m["username"] != "Moderator_Bot"]
    if last_user_msgs:
        last_msg = last_user_msgs[-1]
        
        st.markdown("---")
        st.markdown("### 🔬 Real-Time AI Inference Analytics (Last Message)")
        
        # If model is loaded, we can re-analyze or fetch details
        # Let's run a fresh analysis on the last message to show detailed bar charts
        raw_txt = last_msg.get("original", last_msg["text"])
        user = last_msg["username"]
        
        # Re-run for visual analytics display
        rep = moderator.analyze_message(raw_txt, username=user)
        
        col_m1, col_m2 = st.columns([1, 1])
        
        with col_m1:
            st.markdown(f"**Original message:** `{raw_txt}`")
            st.markdown(f"**Preprocessed comment:** `{rep['preprocessed_text']}`")
            st.markdown(f"**Redacted output:** `{rep['redacted_text']}`")
            
            # Severity color block
            sev = rep['severity_score']
            card_class = "glow-card-green"
            if rep['action'] == "WARN":
                card_class = "glow-card-yellow"
            elif rep['action'] == "MUTE":
                card_class = "glow-card-orange"
            elif rep['action'] == "BAN":
                card_class = "glow-card-red"
                
            st.markdown(f"""
            <div class='{card_class}'>
                <div style='font-size: 0.85rem; text-transform: uppercase; color: #888;'>AI Computed Severity Score</div>
                <div style='font-size: 2.2rem; font-weight: bold; margin: 4px 0;'>{sev:.2f} / 5.00</div>
                <div style='font-weight: 600; font-size: 1rem;'>Action Recommended: {rep['action']} ({rep['action_reason']})</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col_m2:
            st.markdown("**Predicted Toxicity Class Probabilities:**")
            
            # Draw pretty progress bars representing probabilities
            categories_disp = {
                'toxic': 'Toxic (General)',
                'severe_toxic': 'Severe Toxic',
                'obscene': 'Profanity / Obscene',
                'threat': 'Threat / Violent',
                'insult': 'Insulting',
                'identity_hate': 'Hate Speech / Slur',
                'spam': 'Spam / Advertising'
            }
            
            for cat, display_name in categories_disp.items():
                prob = rep['probabilities'].get(cat, 0.0)
                flag = rep['flags'].get(cat, 0)
                
                color = "#2979FF" # default blue
                if flag == 1:
                    # neon color for active flags
                    if cat in ['severe_toxic', 'identity_hate']:
                        color = "#FF1744" # red
                    elif cat in ['threat', 'obscene']:
                        color = "#FF9100" # orange
                    else:
                        color = "#FFC107" # yellow
                        
                st.write(f"{display_name}: **{prob:.1%}** {'🔥 FLAGGED' if flag == 1 else ''}")
                st.progress(float(prob))

# ---------------------------------------------------------
# TAB 2: Admin Analytics Dashboard
# ---------------------------------------------------------
with tab_analytics:
    st.markdown("### 📊 Admin Moderation Command Dashboard")
    
    # Summary Metrics Row
    m_col1, m_col2, m_col3, m_col4 = st.columns(4)
    
    # Calculate stats from active session chat history
    all_chat = st.session_state.chat_history
    user_msgs = [m for m in all_chat if m["username"] != "Moderator_Bot"]
    sys_msgs = [m for m in all_chat if m["username"] == "Moderator_Bot"]
    
    total_messages = len(user_msgs)
    warns_issued = sum(1 for m in sys_msgs if "WARNED" in m["text"])
    mutes_issued = sum(1 for m in sys_msgs if "MUTED" in m["text"])
    bans_issued = sum(1 for m in sys_msgs if "BANNED" in m["text"])
    
    with m_col1:
        st.metric("Total Messages Analyzed", total_messages)
    with m_col2:
        st.metric("Warnings Dispatched", warns_issued)
    with m_col3:
        st.metric("Active Player Mutings", mutes_issued)
    with m_col4:
        st.metric("Permanent Player Bans", bans_issued)
        
    st.markdown("---")
    
    # Split charts
    chart_col1, chart_col2 = st.columns(2)
    
    with chart_col1:
        st.markdown("#### Live Severity Scores Timeline")
        if user_msgs:
            # Line plot of severity scores
            sevs = [m.get("severity", 0.0) for m in user_msgs]
            indices = list(range(1, len(sevs) + 1))
            
            fig, ax = plt.subplots(figsize=(6, 3.5))
            plt.style.use('dark_background')
            fig.patch.set_facecolor('#0E1117')
            ax.set_facecolor('#1A1C23')
            
            ax.plot(indices, sevs, marker='o', color='#FF1744', linewidth=2, label='Severity')
            # Add threshold indicator lines
            ax.axhline(y=warn_thresh, color='#FFC107', linestyle='--', alpha=0.5, label='Warn Threshold')
            ax.axhline(y=mute_thresh, color='#FF9100', linestyle='--', alpha=0.5, label='Mute Threshold')
            ax.axhline(y=ban_thresh, color='#FF1744', linestyle='--', alpha=0.5, label='Ban Threshold')
            
            ax.set_xlabel('Sequence of Message', color='white')
            ax.set_ylabel('Severity Score (0-5)', color='white')
            ax.tick_params(colors='white')
            ax.set_ylim(0, 5.2)
            ax.legend(facecolor='#1A1C23', labelcolor='white', framealpha=0.6, fontsize='small')
            
            st.pyplot(fig)
        else:
            st.info("No messages in queue to chart timeline.")
            
    with chart_col2:
        st.markdown("#### Category Infraction Distribution")
        if st.session_state.user_action_history:
            # Sum up flags from history
            hist_df = pd.DataFrame([h['flags'] for h in st.session_state.user_action_history])
            
            if not hist_df.empty:
                sum_flags = hist_df.sum().reset_index()
                sum_flags.columns = ['Category', 'Count']
                
                fig, ax = plt.subplots(figsize=(6, 3.5))
                plt.style.use('dark_background')
                fig.patch.set_facecolor('#0E1117')
                ax.set_facecolor('#1A1C23')
                
                sns.barplot(data=sum_flags, x='Category', y='Count', palette='cool', ax=ax)
                ax.set_xlabel('Toxicity Class', color='white')
                ax.set_ylabel('Flag Count', color='white')
                ax.tick_params(colors='white')
                plt.xticks(rotation=45)
                
                st.pyplot(fig)
        else:
            # Standard pre-validation check
            # Load and display saved validation performance charts if they exist
            if os.path.exists("artifacts/evaluation_metrics.png"):
                st.image("artifacts/evaluation_metrics.png", caption="Model Offline Validation Performance Matrix")
            else:
                st.info("Simulate more custom player messages in Tab 1 to dynamically compile active infraction distribution charts here.")
                
    # Detailed Moderator Logs Table
    st.markdown("### 📝 Detailed AI Moderator Session Log")
    if st.session_state.user_action_history:
        log_data = []
        for rep in st.session_state.user_action_history:
            log_data.append({
                "User": rep['username'],
                "Message": rep['original_text'],
                "Severity": rep['severity_score'],
                "Action": rep['action'],
                "Reason": rep['action_reason'],
                "Latency": f"{rep['latency_ms']} ms"
            })
        st.dataframe(pd.DataFrame(log_data), use_container_width=True)
    else:
        st.caption("Interact with the live chat simulator in Tab 1 to populate detailed system reports.")

# ---------------------------------------------------------
# TAB 3: Mitigation Strategies Policy
# ---------------------------------------------------------
with tab_policy:
    st.markdown("### 📜 Mitigation Policies & Escalation Matrix")
    st.write("A structured policy framework designed to balance gaming server security and community freedom.")
    
    st.markdown("""
    To preserve a fun and cooperative gaming atmosphere, our live chat operates on a tiered moderation model that evaluates structural message patterns (spam) and semantics (toxicity, hate speech, threats) using high-precision AI.
    
    #### ⚖️ Tiered Escalation Matrix
    """)
    
    # Draw table
    col_p_data = {
        "Severity Score Range": ["0.00 – 1.00 (Safe)", "1.00 – 2.50 (Mild Hazard)", "2.50 – 4.00 (Medium Hazard)", "4.00 – 5.00 (Extreme Hazard)"],
        "Violations Detected": ["No violations / Standard gaming conversation", "Spam links, minor profanity, low-level insults", "Excessive obscenities, slurs, targeted player abuse", "Hate speech, self-harm incitement (KYS), real-life threats"],
        "Moderator Bot Action": ["**ALLOW** (No action taken)", "**WARN** (Standard chat warning prompt)", "**MUTE** (Remove text and mute mic/chat for 5 minutes)", "**BAN** (Terminate user session and black-list IP)"],
        "Mitigation Goal": ["Facilitate active gameplay", "Provide learning guardrails for players", "De-escalate immediate arguments and shield server", "Defend platform integrity and legal safety"]
    }
    st.table(pd.DataFrame(col_p_data))
    
    st.markdown("""
    #### 🛡️ Key Features of our Moderation Mitigation:
    1. **Context-Aware Preprocessing**: Normalizes abbreviations (e.g. *kys*, *stfu*) and parses emojis (e.g. 🖕) into textual semantics to prevent simple bypasses.
    2. **Contextual Word Redaction**: Instead of censoring entire sentences, the moderator replaces detected target profanities with `****`, preserving context for non-violating terms.
    3. **Precision Guarantee**: The severe-toxic category operates at **>80% Precision** to minimize false positives, preventing unwarranted bans on competitive banter (e.g., standard "trash talk").
    4. **Rate Limit Defenses**: Identifies chat flooding (more than 3 messages in 2.5 seconds) to immediately flag spammers.
    """)
